
/*
* Real-Time Workshop S-function Target for model Subsystem. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Sun Jul 08 16:24:44 2007
*/

#include "Subsystem_sfcn_rtw/Subsystem_sf.h"

