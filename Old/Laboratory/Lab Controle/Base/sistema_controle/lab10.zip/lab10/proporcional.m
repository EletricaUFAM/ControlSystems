G1=zpk([],[-5 -2 -1],10)
rlocus(G1)
%%[k1 P]=rlocfind(G1)
hold on
sgrid(0.6,0)
[k1 P]=rlocfind(G1)
