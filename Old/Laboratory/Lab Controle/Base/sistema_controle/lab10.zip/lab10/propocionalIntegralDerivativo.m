G1=zpk([],[-5 -2 -1],10)
rlocus(G1)
hold on
%sgrid(0.6,0)
%[k1 P]=rlocfind(G1)

N2=10
D2=conv([1 0],conv([1 5], [1 3 2])+[0 0 0 10*k1])
%rlocus(N2,D2)

%[k2 P]=rlocfind(N2,D2)
% alterando k1
k1=0.9
D2=conv([1 0],conv([1 5], [1 3 2])+[0 0 0 10*k1])
rlocus(N2,D2)
hold on
sgrid(0.6,0)
[k2 P]= rlocfind(N2,D2)

% parte do PID k1 e k2 fixos e k3 a ser definido

N3=[10 0 0]
D3=D2+[0 0 0 0 10*k2]
rlocus(N3,D3)

figure(2)
rlocus(N3,D3)
hold on
sgrid(0.6,0)
[k3 P]= rlocfind(N3,D3)
