

%% PD
k1=50
N4=[10 0]
D4=conv([1 3 2],[1 5])+[0 0 0 10*k1]
rlocus(N4, D4)
hold on
sgrid(0.6,0)
%[k3 P]=rlocfind(N4,D4)

% nao resolve a reta de zeta nao cruza o root locus

% novo k1=11.6
%%%
k1=11.6

D4=conv([1 3 2],[1 5])+[0 0 0 10*k1]
figure(2)
rlocus(N4, D4)
hold on
sgrid(0.6,0)
[k3 P]=rlocfind(N4,D4)


%% PID

N5=10
D5=conv([1 0],conv([1 3 2],[1 5])+[0 0 10*k3 10*k1])
figure(3)

rlocus(N5, D5)
sgrid(0.6,0)
[k2 P]=rlocfind(N5,D5)